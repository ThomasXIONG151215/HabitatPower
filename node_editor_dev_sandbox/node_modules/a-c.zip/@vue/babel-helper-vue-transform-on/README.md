# @vue/babel-helper-vue-transform-on

A package used internally by vue jsx transformer to transform events.

on: { click: xx } --> onClick: xx
