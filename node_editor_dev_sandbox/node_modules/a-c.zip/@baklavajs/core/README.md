# `baklavajs-core`

> TODO: description

## Usage

```
const baklavajsCore = require('baklavajs-core');

// TODO: DEMONSTRATE API
```
