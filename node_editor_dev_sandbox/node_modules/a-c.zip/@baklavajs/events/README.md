# `@baklavajs/events`

> TODO: description

## Usage

```
const events = require('@baklavajs/events');

// TODO: DEMONSTRATE API
```
