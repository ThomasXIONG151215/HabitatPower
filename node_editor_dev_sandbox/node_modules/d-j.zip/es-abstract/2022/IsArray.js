'use strict';

// https://ecma-international.org/ecma-262/6.0/#sec-isarray
module.exports = require('../helpers/IsArray');
