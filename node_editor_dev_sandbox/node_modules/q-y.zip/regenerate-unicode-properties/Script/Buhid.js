const set = require('regenerate')();
set.addRange(0x1740, 0x1753);
exports.characters = set;
