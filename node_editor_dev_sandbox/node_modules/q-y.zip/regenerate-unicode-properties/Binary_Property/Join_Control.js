const set = require('regenerate')();
set.addRange(0x200C, 0x200D);
exports.characters = set;
