const set = require('regenerate')();
set.addRange(0x11A50, 0x11AA2);
exports.characters = set;
