const set = require('regenerate')();
set.addRange(0x531, 0x556).addRange(0x559, 0x58A).addRange(0x58D, 0x58F).addRange(0xFB13, 0xFB17);
exports.characters = set;
